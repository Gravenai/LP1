#include "../include/App.h"

int main(int argc, char* argv[]){

    App aplicativo;
    return aplicativo.run(argc, argv);
}

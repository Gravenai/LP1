# Diary
- Projeto de diario criado para a disciplina de Linguagens de Programação I, no semestre 2020.5 da UFRN-Brasil.

# Como usar:

# Ultilização por comando: 
- Use <nome do programa> add <mensagem>: para adicionar uma nova mensagem.
- Use <nome do programa> list: para listar as mensagens adicionadas no diario
- Use <nome do programa> search <string de busca>: para pesquisar pro uma mensagem buscando pelo termo <string de busca>
- Use <nome do programa> interactive: para acessar o menu interativo do programa

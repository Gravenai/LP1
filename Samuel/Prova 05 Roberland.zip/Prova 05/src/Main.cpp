#include "../include/Front.hpp"

int main (){
	Front front;
	front.run();
	return 0;
}